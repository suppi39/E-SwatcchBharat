create table users(
name varchar(200),
address varchar(600),
email varchar(200),
password varchar(200),
mobile varchar(200));


