<?php
$server="localhost";
$uname="root";
$pwd="";
$db="wms";

$con=mysqli_connect($server,$uname,$pwd,$db);


?>